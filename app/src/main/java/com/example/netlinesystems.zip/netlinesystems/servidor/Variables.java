package com.example.netlinesystems.servidor;

public class Variables {

    private static final String URLAPI= "http://192.168.100.8:8010";

    public Variables() {
    }

    public static String getURLAPI() {
        return URLAPI;
    }
}
